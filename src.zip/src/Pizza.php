<?php

namespace src;

include_once 'Cell.php';
include_once 'Slide.php';

class Pizza
{
    /**
     * @var integer
     */
    private $numberColumns;

    /**
     * @var integer
     */
    private $numberRows;

    /**
     * @var integer
     */
    private $minEachTopic;

    /**
     * @var integer
     */
    private $maxCellsSlide;

    /**
     * @var array[Cell]
     */
    private $cells;

    /**
     * @var array[Slide]
     */
    private $slides;

    /**
     * Pizza constructor.
     * @param int $numberColumns
     * @param int $numberRows
     * @param int $minEachTopic
     * @param int $maxCellsSlide
     */
    public function __construct($numberRows, $numberColumns, $minEachTopic, $maxCellsSlide)
    {
        $this->numberColumns = $numberColumns;
        $this->numberRows = $numberRows;
        $this->minEachTopic = $minEachTopic;
        $this->maxCellsSlide = $maxCellsSlide;
    }

    /**
     * @return int
     */
    public function getNumberColumns()
    {
        return $this->numberColumns;
    }

    /**
     * @param int $numberColumns
     */
    public function setNumberColumns($numberColumns)
    {
        $this->numberColumns = $numberColumns;
    }

    /**
     * @return int
     */
    public function getNumberRows()
    {
        return $this->numberRows;
    }

    /**
     * @param int $numberRows
     */
    public function setNumberRows($numberRows)
    {
        $this->numberRows = $numberRows;
    }

    /**
     * @return int
     */
    public function getMinEachTopic()
    {
        return $this->minEachTopic;
    }

    /**
     * @param int $minEachTopic
     */
    public function setMinEachTopic($minEachTopic)
    {
        $this->minEachTopic = $minEachTopic;
    }

    /**
     * @return int
     */
    public function getMaxCellsSlide()
    {
        return $this->maxCellsSlide;
    }

    /**
     * @param int $maxCellsSlide
     */
    public function setMaxCellsSlide($maxCellsSlide)
    {
        $this->maxCellsSlide = $maxCellsSlide;
    }

    public function addCell(Vehiculo $cell ){
        $this->cells[Coordinate::c2s($cell->getCoordinate())] = $cell;
    }

    public function getMaxHandicupCell()
    {
        foreach ($this->cells as $id => $cell ){
            if( !$cell->isCut() ) {
                $handicap = $this->getCoordinateHandicap($cell);
                if( isset($handicapRes) && $handicap != INF && $handicap > $handicapRes ){
                    $cellRes = $cell;
                    $handicapRes = $handicap;
                }
            }
        }

        if ( !isset($cellRes) ) return null;
        return $cellRes;
    }

    private function getCoordinateHandicap(Vehiculo $cell )
    {
        $this->cells[$cell->getCoordinateString()]->setIsCut(true);
        $mulplicador = array(
            1,
            -1
        );

        $celdasAdyacentes = 0;
        $handicap = 0;

        foreach ( $mulplicador as $mulplicadorFila ){
            foreach ( $mulplicador as $mulplicadorColumna ) {
//                $axis = true;
                $axis = ( $this->sign($mulplicadorFila) == $this->sign($mulplicadorColumna) ); // repite elementos de los ejes
                for ( $desplazadorFila = ( $axis ? 0 : 1 ); $desplazadorFila < $this->maxCellsSlide; $desplazadorFila++ ){
                    $nuevaFila = $cell->getCoordinate()->getRow() + ( $mulplicadorFila * $desplazadorFila );

                    if ( $nuevaFila < 0 || $nuevaFila >= $this->getNumberRows() ) break;

                    $nuevaCelda =  $this->cells[$nuevaFila.','.$cell->getCoordinate()->getColumn()];

                    if ( $nuevaCelda->getCoordinateString() != $cell->getCoordinateString() && $nuevaCelda->isCut() ) break;

                    for ( $desplazadorColumna = ( $axis ? 0 : 1 ); $desplazadorColumna < $this->maxCellsSlide; $desplazadorColumna++ ){
                        $nuevaColumna = $cell->getCoordinate()->getColumn() + ( $mulplicadorColumna * $desplazadorColumna );

                        if ( $nuevaColumna < 0 || $nuevaColumna >= $this->getNumberColumns() ) break;

                        $nuevaCelda = $this->cells[$nuevaFila.','.$nuevaColumna];

                        $cellsBetween = Coordinate::cellsBetweenCoordinates( $cell->getCoordinate(), $nuevaCelda->getCoordinate() );

                        if ( $cellsBetween == 1 ) continue;

                        if ( $cellsBetween > $this->maxCellsSlide ) break;

                        if ($nuevaCelda->isCut()) {
                            break;
                        } else {
                            $celdasAdyacentes++;
                            if ($cell->getType() == $nuevaCelda->getType()) $handicap++;
                        }

                    }

                }

            }

        }

        $this->cells[$cell->getCoordinateString()]->setIsCut(false);

        if ( $celdasAdyacentes == 0 || $handicap / $celdasAdyacentes == 1 ) $return = INF;
        else $return = ( $handicap / $celdasAdyacentes );

        echo Coordinate::c2s( $cell->getCoordinate() ).': '.$return."\n";
        return $return;
    }

    public function printCells(){
        var_dump($this->cells);
    }

    private function sign($n) {
        return ($n > 0) - ($n < 0);
    }
}